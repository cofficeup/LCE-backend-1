<?php

namespace App\Exceptions;

use RuntimeException;

class PickupSchedulingException extends RuntimeException
{
}
